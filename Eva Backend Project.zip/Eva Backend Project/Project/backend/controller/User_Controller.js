const { json } = require("body-parser");
const {Router} = require("express"); 
const { send } = require("express/lib/response");
const  {User} = require("../database/models")
//const jwt = require("jsonwebtoken")

const  {Share} = require("../database/models")

const router = Router();

//#region unfortunately unfinished jsonwebtoken and login operations 

// function verifyToken(req,res,next){

//     // get token from header
//     const bearerHeader = req.headers['authorization'];

//     if(typeof bearerHeader !== 'undefined'){
//         const bearer = bearerHeader.split(' ');
//         const bearerToken = bearer[1];

//         req.token = bearerToken;

//         next();

//     }else{
//         res.sendStatus(403);
//     }

// }


// router.post('/login', async (req, res) => {
//     try {
//         const user = await User.findOne({
//             where: { username : req.body.username ,password: req.body.password }
//         });

//         if(!user) {
//             return res.status(404).json({ message: 'no such user like that!!' });
//         }
//         else{
//             jwt.sign({user: user}, 'secretkey' , {expiresIn : '30s'}, (err,token) => {
//                 res.json({
//                     token
//                 })
//             })
//         }
        
//     } catch (error) {
//         res.status(500).json({ message: error.message });
//     }
// });

//#endregion

// client buy transaction depends on client id 
router.post('/buy/:id', async(req,res) =>{

    try {
        const {code:codebody,price:pricebody,number:numberbody} = req.body;

        const share = await Share.findOne({
            where : {code: codebody}
        });

        const client = await User.findOne({
            where : {id : req.params.id}
        })

        // client registered??
        if(!client){
            return res.status(400).json({ message: "Non registered client"});
        }
        else{
            // registered share??
            if(!share){
                return res.status(400).json({ message: "Non registered share"});
            }
            else{

                // hisse adeti alım adetinden küçükse
                if(share.number < numberbody){
                    return res.status(400).json({ message:"Not enough share number" });
                }
                else{
                    
                    // kullanıcının birim hisse fiyatı hissenin price ından büyük olmalı
                    if(pricebody <= share.price){
                        var minpricetobuy = share.price + 1
                        //res.send("give more unit price!!  min price for per unit : " + minpricetobuy)
                        return res.status(400).json({ message: "Give more unit price!!  min price for per unit : " + minpricetobuy });
                    }
                    else{

                        var balance_checker = pricebody * numberbody
                        if(balance_checker > client.credit){

                            //res.send("not enough balance!!")
                            return res.status(400).json({ message: 'Not enough balance!!' });
                        }
                        else{

                            var credit = (parseFloat(client.credit.toString()) - parseFloat(pricebody*numberbody.toString())).toFixed(2)
                            var portfolio = []

                            // empty portolio
                            if(client.portfolio.length == 0){
                                portfolio.push(req.body)
                            }
                            // one share
                            else if(client.portfolio.length == 1){
                                // buying same share (update the existing share) 
                                if(req.body.code === client.portfolio[0].code){
                                    req.body.number = req.body.number + client.portfolio[0].number
                                    portfolio.push(req.body)
                                }
                                // buying another share (adding new share to portfolio)
                                else
                                {
                                    //portfolio = [client.portfolio,req.body]
                                    portfolio.push(client.portfolio[0])
                                    portfolio.push(req.body)
                                }

                            }
                            // more than one share
                            else
                            {
                                var i = 0;
                                var checker = false;

                                client.portfolio.forEach(element => {
                                    if(req.body.code === element.code){
                                        checker = true
                                        client.portfolio[i].number = element.number + req.body.number
                                        client.portfolio[i].price = req.body.price
                                    }
                                    i++
                                });

                                if(checker){
                                    client.portfolio.forEach(element => {
                                        portfolio.push(element)
                                    });
                                }
                                else{
                                    client.portfolio.forEach(element => {
                                        portfolio.push(element)
                                    });
                                    portfolio.push(req.body)
                                }
                            }


                            User.update(
                                {credit,portfolio},
                                {
                                    returning: true,
                                    where: { id: req.params.id }
                                }
                            );
                            
                            var number = share.number - numberbody
                            var price = pricebody

                            Share.update(
                                {number,price},
                                {
                                    returning: true,
                                    where: {code: codebody}
                                }
                            );

                            res.send("Successfully buy op.");
                        }   
                    }
                }
            }
        }
    }
    catch (error) {
        res.status(500).json({ message: error.message });
    }      
});

// client sell transaction depends on client id 
router.post('/sell/:id', async(req,res) => {
    try{
        const {code:codebody,price:pricebody,number:numberbody} = req.body;

        const share = await Share.findOne({
            where : {code: codebody}
        });

        const client = await User.findOne({
            where : {id : req.params.id}
        })

        var usersharecount = 0.00;
        var usersharesellprice = 0.00;
        var i = 0

        // client registered??
        if(!client){
            res.send("no such registered user")
        }
        else{
            // share registered??
            if(!share){
                res.send("no such registered share")
            }
            else{

                // hisse kullanıcıda var mı
                var checker = false
                if(client.portfolio.length > 1)
                {
                    for(let w=0 ; w<client.portfolio.length ; w++){
                        if(client.portfolio[w].code === req.body.code){
                            checker = true
                            usersharecount = client.portfolio[w].number
                            usersharesellprice = client.portfolio[w].price
                            i = w
                        }
                    }
                    // client.portfolio.forEach(element => {
                    //     if(element.code === req.body.code){
                    //         checker = true
                    //         usersharecount = element.number
                    //         usersharesellprice = element.price   
                    //     }
                    //     i++
                    // });
                }
                if(client.portfolio.length == 1)
                {
                    if(client.portfolio[0].code === req.body.code){
                        checker = true
                        usersharecount = client.portfolio[0].number
                        usersharesellprice = client.portfolio[0].price
                    }
                }


                if(!checker){
                    res.send("not include this share in user portfolio")

                }else{

                    //satılan share adeti, sahip olunandan küçük ya da eşit olmalı
                    if(req.body.number > usersharecount){
                        res.send("check sell count again!!")
                    }

                    else{
                        

                        // satma fiyatı hisse price ından küçük olmalı
                        if(req.body.price >= share.price){
                            res.send("check sell price again!!")
                        }
                        else{

                            
                            var number = share.number + req.body.number
                            var price = req.body.price

                            Share.update(
                                {number,price},
                                {
                                    returning: true,
                                    where: {code: codebody}
                                }
                            );

                            
                            var portfolio = []

                            // hepsini satıyorsa
                            if(usersharecount === req.body.number){
                                if(client.portfolio.length > 1){
                                    client.portfolio.forEach(element => {
                                        if(req.body.code === element.code){
                                        }
                                        else{
                                            portfolio.push(element)
                                        }
                                    });
                                    
                                }
                                else{
                                }
                            }
                            // bir kısmını satıyorsa   req.body.number <  usersharecount
                            else{

                                // portfolio 1 den fazla elemana sahipse
                                if(client.portfolio.length > 1){
                                    client.portfolio.forEach(element => {
                                        if(req.body.code === element.code){
                                            element.number = element.number - req.body.number
                                            portfolio.push(element)
                                        }
                                        else{
                                            portfolio.push(element)
                                        }
                                    });
                                    
                                }
                                //tek eleman
                                else{

                                    client.portfolio[0].number = client.portfolio[0].number - req.body.number
                                    portfolio.push(client.portfolio[0])

                                }
                            }

                            
                            var one = client.credit
                            var two = req.body.number * req.body.price

                            var credit = (parseFloat(one.toString()) + parseFloat(two.toString())).toFixed(2)

                            User.update(
                                {credit,portfolio},
                                {
                                    returning: true,
                                    where: { id: req.params.id }
                                }
                            );
                            res.send("Successfull sell op  ")
                        }   
                    }
                }
            }
        }
    }
    catch (error) {
        res.status(500).json({ message: error.message });
    } 

})

// Create blog post
router.post('/', async (req, res) => {
    try {
        const { username, password, credit, portfolio } = req.body;
  
        const post = await User.create({
            username,
            password,
            credit,
            portfolio
        });

        return res.status(201).json({ post });
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

// Get all posts
router.get('/', async (req, res) => {
    
    try {    
        const users = await User.findAll();
        return res.status(200).json({ users });
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

// Get post by id
router.get('/:id' ,async (req, res) => {
    try {

        const user = await User.findOne({
            where: { id: req.params.id }
        });

        if(!user) {
            return res.status(404).json({ message: 'the user with the given id was not found' });
        }
        return res.status(200).json({ user });
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

// Get portfolio by id
router.get('/portfolio/:id', async (req, res) => {
    try {
        const user = await User.findOne({
            where: { id: req.params.id }
        });

        if(!user) {
            return res.status(404).json({ message: 'the user with the given id was not found' });
        }
        
        res.send(user.portfolio.map(function(portfolio){ return portfolio['Code'] }))
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

// Update
router.patch('/:id', async (req, res) => {
    try {
        const { username, password, credit, portfolio } = req.body;
        const users = await User.update(
        { username, password, credit, portfolio },
        {
            returning: true,
            where: { id: req.params.id }
        }
        );
    
        if (users[0] === 0)
            return res.status(404).json({ message: 'The user with the given id was not found' });
        
        const user = users[1][0].dataValues;

        return res.status(200).json({ user });
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

// Delete post
router.delete('/:id', async (req, res) => {
    try {
        const user = await User.destroy({ where: { id: req.params.id } });
        if (!user)
            return res.status(404).json({ message: 'The post with the given id was not found' });
    
        return res.status(200).json({ message: 'The post was deleted successfully' });
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

module.exports = router;