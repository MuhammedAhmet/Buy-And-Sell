
const {Router} = require("express") 
const  {Share} = require("../database/models")


const router = Router();

// Create blog post
router.post('/', async (req, res) => {
    try {
        const { code, price, number } = req.body;
  
        const share = await Share.create({
            code,
            price,
            number
        });

        return res.status(201).json({ share });
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

// Get all posts
router.get('/', async (req, res) => {
    try {
        const shares = await Share.findAll();
        return res.status(200).json({ shares });
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

// Get post by id
router.get('/:id', async (req, res) => {
    try {
        const share = await Share.findOne({
            where: { id: req.params.id }
        });

        if(!share) {
            return res.status(404).json({ message: 'the post with the given id was not found' });
        }

        return res.status(200).json({ share });
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

// Update post
router.patch('/:id', async (req, res) => {
    try {
        const { code, price, number } = req.body;
        const shares = await Share.update(
        { code, price, number },
        {
            returning: true,
            where: { id: req.params.id }
        }
        );
    
        if (shares[0] === 0)
            return res.status(404).json({ message: 'The post with the given id was not found' });
        
        const share = shares[1][0].dataValues;

        return res.status(200).json({ share });
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

// Delete post
router.delete('/:id', async (req, res) => {
    try {
        const share = await Post.destroy({ where: { id: req.params.id } });
        if (!share)
            return res.status(404).json({ message: 'The post with the given id was not found' });
    
        return res.status(200).json({ message: 'The post was deleted successfully' });
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

module.exports = router;