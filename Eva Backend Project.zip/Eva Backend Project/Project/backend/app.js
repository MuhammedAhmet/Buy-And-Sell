const express = require("express")
const {Router} = require("express"); 


const bodyParser = require("body-parser")

const  {User} = require("./database/models")

const router = Router();

const app = express()
app.use(express.json());

////////////////////////////////////////////////////
var userRoutes = require("./controller/User_Controller")
var shareRoutes = require("./controller/Share_Controller")
////////////////////////////////////////////////////


app.listen(4000, () => {
    console.log("Sunucu Çalışıyor...");
});

////////////////////////////////////////////////////
app.use("/api/user",userRoutes);
app.use("/api/share",shareRoutes);
////////////////////////////////////////////////////


app.get('/', function(req,res){
    //res.send("Selamlar...");
    res.send('<h1>Merhaba Express</h1>');
    
});
